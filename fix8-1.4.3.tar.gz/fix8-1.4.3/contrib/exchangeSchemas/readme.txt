Some exchanges enhance the standard FIX specification to meet thier needs better.
These FIX XML definitions are modified from the standard FIX specification to closely match the exchanges definition and usage.
The goal is to have an exchange specific FIX definiton for each exchange which includes all the custom exchange fields.
Note that some of the types might be modified since some exchanges deviate from the standard on some of the standard FIX fields.


