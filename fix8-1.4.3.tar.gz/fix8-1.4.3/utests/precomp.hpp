#if !defined(FIX8_UTESTS_PRECOMP_H_)
#define FIX8_UTESTS_PRECOMP_H_

#include "f8headers.hpp"

#endif // FIX8_UTESTS_PRECOMP_H_
